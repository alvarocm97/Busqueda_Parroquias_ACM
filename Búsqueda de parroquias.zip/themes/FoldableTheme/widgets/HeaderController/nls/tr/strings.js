define({
  "_widgetLabel": "Başlık Denetleyici",
  "signin": "Oturum aç",
  "signout": "Oturumu kapat",
  "about": "Hakkında",
  "signInTo": "Şurada oturum aç",
  "cantSignOutTip": "Bu işlev ön izleme modunda yok.",
  "more": "diğer"
});